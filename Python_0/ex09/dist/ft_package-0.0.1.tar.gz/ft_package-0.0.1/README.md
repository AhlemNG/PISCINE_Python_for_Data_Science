# ft_package

A sample Python package.

## Installation

Install the package locally or via PyPI/TestPyPI:

```bash
pip install ft_package  # ou le .whl / .tar.gz localement