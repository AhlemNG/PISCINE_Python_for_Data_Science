def count_in_list(lst, value):
    """Compter combien de fois `value` apparaît dans la liste `lst`."""
    return lst.count(value)
