__version__ = "0.0.1"

from .count_in_list import count_in_list
